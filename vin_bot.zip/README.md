Step 1
-------
Create a virtual environment with python 3.10
python3.10 -m venv venv310

Step 2
-------
Install requirements

Step 3
--------
Start virtual environment

Step 4
--------
Run python3 vin_bot.py

